from flask import Flask, render_template, request, jsonify, redirect
import sqlite3, os, re, datetime

app = Flask(__name__)
DB_PATH = os.path.join(os.path.dirname(__file__), "trackila.db")

# ---------------- DB SETUP ----------------
def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    # Schedules
    c.execute("""CREATE TABLE IF NOT EXISTS schedules (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source TEXT,
            destination TEXT,
            departure TEXT,   -- 'HH:MM' 24-hr
            arrival TEXT      -- 'HH:MM'
        )""")
    # Fares
    c.execute("""CREATE TABLE IF NOT EXISTS fares (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source TEXT,
            destination TEXT,
            fare INTEGER      -- in INR
        )""")
    # Complaints
    c.execute("""CREATE TABLE IF NOT EXISTS complaints (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            contact TEXT,
            message TEXT,
            created_at TEXT
        )""")
    conn.commit()
    # Seed data if empty
    c.execute("SELECT COUNT(*) FROM schedules")
    if c.fetchone()[0] == 0:
        schedules_seed = [
            ("Mumbai", "Pune", "06:30", "10:15"),
            ("Mumbai", "Pune", "09:00", "12:30"),
            ("Mumbai", "Nashik", "07:00", "11:00"),
            ("Pune", "Mumbai", "08:00", "11:45"),
            ("Delhi", "Jaipur", "07:15", "11:00"),
            ("Delhi", "Agra", "06:45", "10:00"),
            ("Bengaluru", "Mysuru", "08:30", "11:00"),
            ("Chennai", "Coimbatore", "07:00", "13:15"),
            ("Jaipur", "Delhi", "17:30", "21:15")
        ]
        c.executemany("INSERT INTO schedules (source,destination,departure,arrival) VALUES (?,?,?,?)", schedules_seed)
    c.execute("SELECT COUNT(*) FROM fares")
    if c.fetchone()[0] == 0:
        fares_seed = [
            ("Mumbai", "Pune", 550),
            ("Mumbai", "Nashik", 600),
            ("Pune", "Mumbai", 550),
            ("Delhi", "Jaipur", 450),
            ("Delhi", "Agra", 400),
            ("Bengaluru", "Mysuru", 350),
            ("Chennai", "Coimbatore", 700),
            ("Jaipur", "Delhi", 450)
        ]
        c.executemany("INSERT INTO fares (source,destination,fare) VALUES (?,?,?)", fares_seed)
    conn.commit()
    conn.close()

def db():
    return sqlite3.connect(DB_PATH)

# ---------------- NLU HELPERS ----------------
CITY_PATTERN = r"(Mumbai|Pune|Nashik|Delhi|Jaipur|Agra|Bengaluru|Mysuru|Chennai|Coimbatore)"
def extract_route(text):
    text = text.title()
    m = re.search(rf"from\s+{CITY_PATTERN}\s+(?:to|-|->)\s+{CITY_PATTERN}", text, re.IGNORECASE)
    if m:
        cities = re.findall(CITY_PATTERN, m.group())
        if len(cities) >= 2:
            return cities[0], cities[1]
    m = re.search(rf"{CITY_PATTERN}\s+(?:to|-|->)\s+{CITY_PATTERN}", text, re.IGNORECASE)
    if m:
        cities = re.findall(CITY_PATTERN, m.group())
        if len(cities) >= 2:
            return cities[0], cities[1]
    return None, None

def intent_and_entities(text):
    t = text.lower()
    if any(k in t for k in ["time", "timing", "schedule", "next bus", "when"]):
        s, d = extract_route(text)
        return "schedule", {"source": s, "destination": d}
    if any(k in t for k in ["fare", "price", "ticket cost", "cost"]):
        s, d = extract_route(text)
        return "fare", {"source": s, "destination": d}
    if any(k in t for k in ["route", "go to", "reach"]):
        s, d = extract_route(text)
        return "route", {"source": s, "destination": d}
    if any(k in t for k in ["complaint", "complain", "report", "issue"]):
        return "complaint", {}
    if any(k in t for k in ["hi", "hello", "namaste", "hey"]):
        return "greet", {}
    return "fallback", {}

# ---------------- BOT LOGIC ----------------
def handle_schedule(source, destination):
    if not source or not destination:
        return "Please tell me the route like 'Mumbai to Pune'."
    con = db()
    c = con.cursor()
    c.execute("SELECT departure,arrival FROM schedules WHERE source=? AND destination=? ORDER BY departure",
              (source, destination))
    rows = c.fetchall()
    con.close()
    if not rows:
        return f"Sorry, I couldn't find schedules for {source} → {destination}."
    lines = [f"Next buses {source} → {destination}:"]
    for dep, arr in rows[:5]:
        lines.append(f"• Departs {dep}, Arrives {arr}")
    return "\n".join(lines)

def handle_fare(source, destination):
    if not source or not destination:
        return "Please mention source and destination, e.g., 'fare from Delhi to Jaipur'."
    con = db()
    c = con.cursor()
    c.execute("SELECT fare FROM fares WHERE source=? AND destination=?", (source, destination))
    r = c.fetchone()
    con.close()
    if not r:
        return f"Fare info not available for {source} → {destination}."
    return f"The fare from {source} to {destination} is ₹{r[0]}."

def handle_route(source, destination):
    if source and destination:
        return f"Take the direct route {source} → {destination}. You can catch the next available bus; ask 'schedule for {source} to {destination}'."
    return "Tell me where you are and where you want to go, like 'route from Bengaluru to Mysuru'."

def store_complaint(name, contact, message):
    con = db()
    c = con.cursor()
    c.execute("INSERT INTO complaints (name, contact, message, created_at) VALUES (?,?,?,?)",
              (name, contact, message, datetime.datetime.now().isoformat(timespec='seconds')))
    con.commit()
    con.close()

# ---------------- ROUTES ----------------
@app.route("/")
def index():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json() or {}
    text = (data.get("message") or "").strip()
    if not text:
        return jsonify({"reply": "Please type a message."})
    intent, ents = intent_and_entities(text)

    if intent == "greet":
        return jsonify({"reply": "Hello! I'm Trackila Assistant. Ask me about bus timings, fares, routes, or type 'complaint' to register an issue."})
    if intent == "schedule":
        reply = handle_schedule(ents.get("source"), ents.get("destination"))
        return jsonify({"reply": reply})
    if intent == "fare":
        reply = handle_fare(ents.get("source"), ents.get("destination"))
        return jsonify({"reply": reply})
    if intent == "route":
        reply = handle_route(ents.get("source"), ents.get("destination"))
        return jsonify({"reply": reply})
    if intent == "complaint":
        return jsonify({"reply": "Please share your complaint in this format: 'complaint: <your message>'. You can optionally add your name and phone like 'complaint: Bus was late - Name: Anchal, Phone: 98xxxxxx'"})
    if text.lower().startswith("complaint:"):
        import re
        name_match = re.search(r"name\s*:\s*([A-Za-z ]+)", text, re.IGNORECASE)
        phone_match = re.search(r"(?:phone|mobile|contact)\s*:\s*([\d+\- ]+)", text, re.IGNORECASE)
        name = name_match.group(1).strip() if name_match else "Anonymous"
        contact = phone_match.group(1).strip() if phone_match else ""
        msg = re.sub(r"^complaint:\s*", "", text, flags=re.IGNORECASE).strip()
        store_complaint(name, contact, msg)
        return jsonify({"reply": "Your complaint has been registered. Our team will review it. Thank you."})
    return jsonify({"reply": "Sorry, I didn't get that. You can ask for 'schedule Mumbai to Pune', 'fare Delhi to Jaipur', 'route Bengaluru to Mysuru', or type 'complaint'."})

@app.route("/admin/complaints")
def complaints_page():
    con = db()
    c = con.cursor()
    c.execute("SELECT id, name, contact, message, created_at FROM complaints ORDER BY id DESC")
    rows = c.fetchall()
    con.close()
    return render_template("complaints.html", complaints=rows)

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
